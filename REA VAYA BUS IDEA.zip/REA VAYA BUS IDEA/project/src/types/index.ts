export interface Transaction {
  id: string;
  date: string;
  amount: number;
  type: 'tap-in' | 'tap-out' | 'reload';
  location: string;
}

export interface VirtualCard {
  cardNumber: string;
  balance: number;
  lastTransaction?: Transaction;
}

export interface Route {
  id: string;
  name: string;
  type: 'T' | 'C' | 'F'; // Trunk, Complementary, Feeder
  status: 'normal' | 'delayed' | 'suspended';
  stations: string[];
}