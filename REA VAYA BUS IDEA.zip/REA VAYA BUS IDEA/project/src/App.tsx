import React, { useState } from 'react';
import { Header } from './components/Header';
import { VirtualCard } from './components/VirtualCard';
import { QuickActions } from './components/QuickActions';
import { ServiceStatus } from './components/ServiceStatus';
import { LoginPage } from './components/LoginPage';
import { RoutesPage } from './components/RoutesPage';
import { ReloadCardPage } from './components/ReloadCardPage';
import { ScannerPage } from './components/ScannerPage';
import { InfoPage } from './components/InfoPage';

type Page = 'home' | 'routes' | 'reload' | 'scanner' | 'info';

function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [cardBalance, setCardBalance] = useState(50.00);

  // Mock data - in a real app this would come from your backend
  const mockCard = {
    cardNumber: '1234567890123456',
    balance: cardBalance,
    lastTransaction: {
      id: '1',
      date: '2024-03-14T10:30:00Z',
      amount: -8.50,
      type: 'tap-in' as const,
      location: 'Park Station'
    }
  };

  const handleLogin = (email: string, password: string) => {
    // In a real app, this would validate credentials with a backend
    console.log('Login attempt:', { email, password });
    setIsAuthenticated(true);
  };

  const handleReload = (amount: number) => {
    setCardBalance(prev => prev + amount);
  };

  if (!isAuthenticated) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const renderPage = () => {
    switch (currentPage) {
      case 'routes':
        return <RoutesPage onBack={() => setCurrentPage('home')} />;
      case 'reload':
        return <ReloadCardPage onBack={() => setCurrentPage('home')} onReload={handleReload} />;
      case 'scanner':
        return <ScannerPage onBack={() => setCurrentPage('home')} />;
      case 'info':
        return <InfoPage onBack={() => setCurrentPage('home')} />;
      default:
        return (
          <main className="container mx-auto px-4 py-6 space-y-6">
            <VirtualCard 
              card={mockCard}
              onReload={() => setCurrentPage('reload')}
            />
            
            <section>
              <h2 className="text-xl font-semibold mb-4 text-slate-900">Quick Actions</h2>
              <QuickActions 
                onTapToPayClick={() => setCurrentPage('scanner')}
                onViewRoutesClick={() => setCurrentPage('routes')}
                onReloadCardClick={() => setCurrentPage('reload')}
                onInfoClick={() => setCurrentPage('info')}
              />
            </section>
            
            <section>
              <h2 className="text-xl font-semibold mb-4 text-slate-900">Service Status</h2>
              <ServiceStatus status="normal" />
            </section>
          </main>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-50">
      <Header onMenuClick={() => setMenuOpen(!menuOpen)} />
      {renderPage()}
    </div>
  );
}

export default App