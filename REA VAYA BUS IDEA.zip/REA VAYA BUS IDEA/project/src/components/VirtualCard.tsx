import React from 'react';
import { CreditCard, RefreshCw } from 'lucide-react';
import type { VirtualCard as VirtualCardType } from '../types';

interface VirtualCardProps {
  card: VirtualCardType;
  onReload: () => void;
}

export function VirtualCard({ card, onReload }: VirtualCardProps) {
  return (
    <div className="bg-gradient-to-r from-blue-600 to-red-600 rounded-xl p-6 text-white shadow-lg">
      <div className="flex justify-between items-start mb-8">
        <CreditCard className="h-8 w-8" />
        <button
          onClick={onReload}
          className="bg-white/20 p-2 rounded-full hover:bg-white/30 transition-colors"
        >
          <RefreshCw className="h-5 w-5" />
        </button>
      </div>
      
      <div className="space-y-4">
        <div>
          <p className="text-sm opacity-80">Card Number</p>
          <p className="font-mono text-lg">
            {card.cardNumber.replace(/(\d{4})/g, '$1 ').trim()}
          </p>
        </div>
        
        <div>
          <p className="text-sm opacity-80">Balance</p>
          <p className="text-2xl font-bold">R {card.balance.toFixed(2)}</p>
        </div>
      </div>
    </div>
  );
}