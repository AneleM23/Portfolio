import React from 'react';
import { ArrowLeft, Phone, Mail, Clock, AlertTriangle, HelpCircle } from 'lucide-react';

interface InfoPageProps {
  onBack: () => void;
}

export function InfoPage({ onBack }: InfoPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 pb-6">
      <div className="bg-red-600 text-white p-4">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 hover:text-white/80 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back</span>
        </button>
        <h1 className="text-2xl font-bold mt-2">Information</h1>
      </div>

      <div className="container mx-auto px-4 mt-6 space-y-6">
        <section className="bg-white rounded-lg p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-slate-900">Bus Types</h2>
          <div className="space-y-4">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded font-medium">T</span>
                <h3 className="font-semibold text-slate-900">Trunk Routes</h3>
              </div>
              <p className="text-slate-600">Main routes connecting major destinations through dedicated bus lanes. These routes form the backbone of the Rea Vaya network.</p>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded font-medium">C</span>
                <h3 className="font-semibold text-slate-900">Complementary Routes</h3>
              </div>
              <p className="text-slate-600">Routes that connect to trunk routes and serve areas slightly off the main corridors. These buses share lanes with regular traffic.</p>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <span className="px-2 py-1 bg-green-100 text-green-800 rounded font-medium">F</span>
                <h3 className="font-semibold text-slate-900">Feeder Routes</h3>
              </div>
              <p className="text-slate-600">Smaller routes that connect residential areas to trunk and complementary routes. These provide crucial last-mile connectivity.</p>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-lg p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-slate-900">Operating Hours</h2>
          <div className="flex items-start space-x-3 text-slate-600">
            <Clock className="h-5 w-5 mt-0.5 flex-shrink-0" />
            <div>
              <p>Monday - Friday: 05:00 - 21:00</p>
              <p>Saturday: 06:00 - 20:00</p>
              <p>Sunday & Public Holidays: 06:30 - 19:30</p>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-lg p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-slate-900">Contact Information</h2>
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <Phone className="h-5 w-5 text-slate-600" />
              <a href="tel:0860562874" className="text-blue-600 hover:text-blue-800">
                0860 562 874
              </a>
            </div>
            <div className="flex items-center space-x-3">
              <Mail className="h-5 w-5 text-slate-600" />
              <a href="mailto:reavaya@joburg.org.za" className="text-blue-600 hover:text-blue-800">
                reavaya@joburg.org.za
              </a>
            </div>
          </div>
        </section>

        <section className="bg-white rounded-lg p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4 text-slate-900">Help & Support</h2>
          <div className="space-y-4">
            <div className="flex items-start space-x-3">
              <AlertTriangle className="h-5 w-5 mt-1 text-red-500" />
              <div>
                <h3 className="font-semibold text-slate-900">Report an Issue</h3>
                <p className="text-slate-600">For service disruptions, card issues, or general complaints, please contact our 24/7 helpline.</p>
              </div>
            </div>
            <div className="flex items-start space-x-3">
              <HelpCircle className="h-5 w-5 mt-1 text-blue-500" />
              <div>
                <h3 className="font-semibold text-slate-900">FAQ</h3>
                <p className="text-slate-600">Find answers to common questions about fares, routes, and card usage in our help center.</p>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}