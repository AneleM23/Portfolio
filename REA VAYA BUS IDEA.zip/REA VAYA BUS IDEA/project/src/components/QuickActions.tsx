import React from 'react';
import { Scan, Map, CreditCard, Info } from 'lucide-react';

interface QuickActionsProps {
  onTapToPayClick: () => void;
  onViewRoutesClick: () => void;
  onReloadCardClick: () => void;
  onInfoClick: () => void;
}

export function QuickActions({ onTapToPayClick, onViewRoutesClick, onReloadCardClick, onInfoClick }: QuickActionsProps) {
  const actions = [
    { icon: Scan, label: 'Tap to Pay', color: 'bg-red-500', onClick: onTapToPayClick },
    { icon: Map, label: 'View Routes', color: 'bg-blue-500', onClick: onViewRoutesClick },
    { icon: CreditCard, label: 'Reload Card', color: 'bg-red-500', onClick: onReloadCardClick },
    { icon: Info, label: 'Info', color: 'bg-blue-500', onClick: onInfoClick },
  ];

  return (
    <div className="grid grid-cols-2 gap-4">
      {actions.map(({ icon: Icon, label, color, onClick }) => (
        <button
          key={label}
          onClick={onClick}
          className="flex flex-col items-center p-4 rounded-lg bg-white shadow-sm hover:shadow-md transition-shadow"
        >
          <div className={`${color} p-3 rounded-full text-white mb-2`}>
            <Icon className="h-6 w-6" />
          </div>
          <span className="text-sm font-medium text-slate-700">{label}</span>
        </button>
      ))}
    </div>
  );
}