import React from 'react';
import { AlertCircle, CheckCircle } from 'lucide-react';

interface ServiceStatusProps {
  status: 'normal' | 'delayed' | 'suspended';
  message?: string;
}

export function ServiceStatus({ status, message }: ServiceStatusProps) {
  const statusConfig = {
    normal: {
      icon: CheckCircle,
      color: 'bg-green-50 text-green-700 border-green-200',
      label: 'All services running normally',
    },
    delayed: {
      icon: AlertCircle,
      color: 'bg-yellow-50 text-yellow-700 border-yellow-200',
      label: 'Some routes experiencing delays',
    },
    suspended: {
      icon: AlertCircle,
      color: 'bg-red-50 text-red-700 border-red-200',
      label: 'Service temporarily suspended',
    },
  };

  const config = statusConfig[status];
  const Icon = config.icon;

  return (
    <div className={`p-4 rounded-lg border ${config.color}`}>
      <div className="flex items-center space-x-2">
        <Icon className="h-5 w-5" />
        <span className="font-medium">{message || config.label}</span>
      </div>
    </div>
  );
}