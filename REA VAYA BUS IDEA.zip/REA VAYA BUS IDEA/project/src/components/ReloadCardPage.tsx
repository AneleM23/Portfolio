import React, { useState } from 'react';
import { ArrowLeft, CreditCard, Plus, Check } from 'lucide-react';

interface ReloadCardPageProps {
  onBack: () => void;
  onReload: (amount: number) => void;
}

export function ReloadCardPage({ onBack, onReload }: ReloadCardPageProps) {
  const [amount, setAmount] = useState('');
  const [selectedCard, setSelectedCard] = useState<string | null>(null);
  const [showSuccess, setShowSuccess] = useState(false);

  const savedCards = [
    { last4: '4242', brand: 'Visa' },
    { last4: '8210', brand: 'Mastercard' },
  ];

  const presetAmounts = [50, 100, 200, 500];

  const handleReload = () => {
    if (amount && selectedCard) {
      onReload(Number(amount));
      setShowSuccess(true);
      setTimeout(() => {
        setShowSuccess(false);
        onBack();
      }, 2000);
    }
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mx-auto">
            <Check className="h-8 w-8 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-slate-900">Reload Successful!</h2>
          <p className="text-slate-600">R {amount} has been added to your card</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-6">
      <div className="bg-red-600 text-white p-4">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 hover:text-white/80 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back</span>
        </button>
        <h1 className="text-2xl font-bold mt-2">Reload Card</h1>
      </div>

      <div className="container mx-auto px-4 mt-6 space-y-6">
        <section>
          <h2 className="text-lg font-semibold mb-4 text-slate-900">Select Amount</h2>
          <div className="grid grid-cols-2 gap-4">
            {presetAmounts.map((preset) => (
              <button
                key={preset}
                onClick={() => setAmount(preset.toString())}
                className={`
                  p-4 rounded-lg text-center font-medium
                  ${amount === preset.toString()
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-slate-900 hover:bg-slate-50'}
                `}
              >
                R {preset.toFixed(2)}
              </button>
            ))}
          </div>
          <div className="mt-4">
            <label className="block text-sm font-medium text-slate-700 mb-2">
              Custom Amount
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              className="block w-full px-3 py-2 border border-slate-300 rounded-md"
              placeholder="Enter amount"
              min="1"
            />
          </div>
        </section>

        <section>
          <h2 className="text-lg font-semibold mb-4 text-slate-900">Payment Method</h2>
          <div className="space-y-3">
            {savedCards.map((card) => (
              <button
                key={card.last4}
                onClick={() => setSelectedCard(card.last4)}
                className={`
                  w-full flex items-center justify-between p-4 rounded-lg
                  ${selectedCard === card.last4
                    ? 'bg-blue-600 text-white'
                    : 'bg-white text-slate-900 hover:bg-slate-50'}
                `}
              >
                <div className="flex items-center space-x-3">
                  <CreditCard className="h-5 w-5" />
                  <span>{card.brand} •••• {card.last4}</span>
                </div>
              </button>
            ))}
            <button className="w-full flex items-center justify-center space-x-2 p-4 rounded-lg bg-white text-blue-600 hover:bg-slate-50">
              <Plus className="h-5 w-5" />
              <span>Add New Card</span>
            </button>
          </div>
        </section>

        <button
          onClick={handleReload}
          disabled={!amount || !selectedCard}
          className={`
            w-full py-3 px-4 rounded-lg font-medium
            ${amount && selectedCard
              ? 'bg-red-600 text-white hover:bg-red-700'
              : 'bg-slate-200 text-slate-500 cursor-not-allowed'}
          `}
        >
          Reload R {amount || '0.00'}
        </button>
      </div>
    </div>
  );
}