import React from 'react';
import { Menu, Bus } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
}

export function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="bg-red-600 text-white p-4 flex items-center justify-between">
      <div className="flex items-center space-x-2">
        <Bus className="h-8 w-8" />
        <h1 className="text-2xl font-bold">Rea Vaya</h1>
      </div>
      <button
        onClick={onMenuClick}
        className="p-2 hover:bg-red-700 rounded-full transition-colors"
      >
        <Menu className="h-6 w-6" />
      </button>
    </header>
  );
}