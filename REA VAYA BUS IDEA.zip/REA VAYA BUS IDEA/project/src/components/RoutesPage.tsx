import React from 'react';
import { ArrowLeft, MapPin } from 'lucide-react';

interface RoutesPageProps {
  onBack: () => void;
}

// Mock data for routes
const routes = [
  {
    id: 'T1',
    name: 'Thokoza Park to Ellis Park East',
    type: 'T',
    stations: ['Thokoza Park', 'Orlando Stadium', 'Park Station', 'Ellis Park'],
    status: 'normal'
  },
  {
    id: 'C3',
    name: 'Inner City Circular',
    type: 'C',
    stations: ['Carlton Centre', 'Park Station', 'Hillbrow', 'Constitution Hill'],
    status: 'delayed'
  },
  {
    id: 'F4',
    name: 'Parktown Connection',
    type: 'F',
    stations: ['Park Station', 'Wits University', 'Parktown'],
    status: 'normal'
  },
];

export function RoutesPage({ onBack }: RoutesPageProps) {
  return (
    <div className="min-h-screen bg-slate-50 pb-6">
      <div className="bg-red-600 text-white p-4">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 hover:text-white/80 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back</span>
        </button>
        <h1 className="text-2xl font-bold mt-2">Bus Routes</h1>
      </div>

      <div className="container mx-auto px-4 mt-6">
        <div className="space-y-4">
          {routes.map((route) => (
            <div
              key={route.id}
              className="bg-white rounded-lg shadow-sm p-4 space-y-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <span className={`
                    px-2 py-1 rounded text-sm font-medium
                    ${route.type === 'T' ? 'bg-blue-100 text-blue-800' :
                      route.type === 'C' ? 'bg-purple-100 text-purple-800' :
                      'bg-green-100 text-green-800'}
                  `}>
                    {route.type}
                  </span>
                  <h3 className="font-semibold text-slate-900">{route.name}</h3>
                </div>
                <span className={`
                  px-2 py-1 rounded-full text-sm
                  ${route.status === 'normal' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'}
                `}>
                  {route.status === 'normal' ? 'On Time' : 'Delayed'}
                </span>
              </div>

              <div className="flex items-center space-x-2 text-sm text-slate-500">
                <MapPin className="h-4 w-4" />
                <span>{route.stations.join(' → ')}</span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}