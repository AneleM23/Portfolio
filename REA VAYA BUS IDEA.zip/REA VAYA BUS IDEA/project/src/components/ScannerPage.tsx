import React, { useEffect, useRef } from 'react';
import { ArrowLeft, Camera } from 'lucide-react';

interface ScannerPageProps {
  onBack: () => void;
}

export function ScannerPage({ onBack }: ScannerPageProps) {
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ 
          video: { facingMode: 'environment' } 
        });
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error('Error accessing camera:', err);
      }
    };

    startCamera();

    return () => {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
    };
  }, []);

  return (
    <div className="min-h-screen bg-slate-900">
      <div className="bg-red-600 text-white p-4">
        <button
          onClick={onBack}
          className="flex items-center space-x-2 hover:text-white/80 transition-colors"
        >
          <ArrowLeft className="h-5 w-5" />
          <span>Back</span>
        </button>
        <h1 className="text-2xl font-bold mt-2">Scan to Pay</h1>
      </div>

      <div className="relative">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          className="w-full h-[calc(100vh-80px)] object-cover"
        />
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="w-64 h-64 border-2 border-white rounded-lg">
            <div className="absolute inset-0 border-2 border-white/50 rounded-lg animate-pulse" />
          </div>
        </div>
        <div className="absolute bottom-0 inset-x-0 p-6 text-center text-white bg-gradient-to-t from-black/80 to-transparent">
          <Camera className="h-6 w-6 mx-auto mb-2" />
          <p>Position the QR code within the frame to scan</p>
        </div>
      </div>
    </div>
  );
}